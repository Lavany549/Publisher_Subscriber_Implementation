import { useState } from "react";
import { sha256 } from 'js-sha256';
import pubsub from "../contracts/pubsub";
function Home(props) {

    // data to be sent to view all subscriptions
    const [mySubs, setMySubs] = useState([]);

    // data to be sent to get the data of a topic
    const [dataVals, setDataVals] = useState({});

    // holds the data published in a topic to be seen
    const [getBack, setGetBack] = useState([]);

    const [displayState, setDisplayState] = useState();

    const viewSubs = async (event) => {
        event.preventDefault();

        // get a list of all topics available to be subscribed
        const res = await fetch("http://localhost:4000/getsubscriptions", {
            method: "POST",
            body: JSON.stringify({ userid: props.id }),
            headers: {
                'Content-Type': 'application/json',
            },
        });
        setMySubs(JSON.parse(await res.text()));
        console.log(mySubs);
    }

    // // get hash of a publishment in solidity
    const getHashSol = async (_pubid, _topicid, d) => {
        console.log(_pubid);
        console.log(_topicid);
        console.log(d);
        const val = await pubsub.methods.retHash(_pubid, _topicid, d.eventID).call();

        const hash = sha256(d.data);

        if (hash == val) {
            setDisplayState({ ...displayState, d });
        }
    }


    // get the unseen data in the topic registered
    const getPublishments = async (event) => {
        event.preventDefault();

        dataVals.userid = props.id;

        console.log(dataVals);

        const res = await fetch("http://localhost:4000/getpublisheddata", {
            method: "POST",
            body: JSON.stringify(dataVals),
            headers: {
                'Content-Type': 'application/json',
            },
        });

        setGetBack(JSON.parse(await res.text()));
        console.log("done");
        console.log(getBack);

        getBack.map((d, id) => {
            if (d.eventID != -1) {
                getHashSol(dataVals.pubid, dataVals.topicid, d);
            }
        });

    }

    return (<>


<h2 class="title">My Subcribed Channels</h2><br></br>
            
            <table>
                
                <tr>
                  <td>Enter PubID :</td>
                  <td><input type="number" name="pubid" onChange={(event) => { setDataVals({ ...dataVals, pubid: parseInt(event.target.value) }) }} value={dataVals.pubid} /></td>
                 
                </tr>
                <tr>
                    <td>Enter TopicID :</td>
                    <td><input type="number" name="topicid" onChange={(event) => { setDataVals({ ...dataVals, topicid: parseInt(event.target.value) }) }} value={dataVals.topicid} /></td>
                    
                  </tr>
                  <tr>
                    <td><button onClick={getPublishments}>Get Latest Data</button></td>
                    <td> {getBack.map((d, idx) => {
            if (d.eventID != -1) {
                return (<h5 key={idx}>{d.eventID}   ------   {d.data}</h5>);
            }
        })}</td>
                   </tr> 
                  
                  <tr>
                    <td><button onClick={viewSubs} >View my Subscriptions</button></td>
                    <td>{mySubs.map((d, idx) => {
            return (<h5 key={idx}>{d.pubID}   ---------------------   {d.topicID}</h5>);
        })}</td>
                    
                  </tr>

                  
                
            </table>
            
       
        

        

    </>);
}

export default Home;