import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import Home from "./Home";
import Publish from "./Publish";
import Subscribe from "./Subscribe.js";
import '../App.css'
import "./stylemain.css"

// this page has the three tabs of the site
function MainPage() {

    // navigator to navigate to other pages
    const navigate = useNavigate();

    // location to get data from navigation
    const location = useLocation();

    const Logout = () => {
        // if logged out navigate to the root page
        // that is login or signup page
        navigate("/", { replace: true });
    }

    return (
        <>
         <Tabs>
                
                <nav class="navbar navbar-default navbar-fixed-top ">
          <div class="container-fluid ">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>                        
              </button>
              <a class="navbar-brand p" href="#myPage"><b>PUBLISHER SUBSCRIBER</b></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
              <ul class="nav navbar-nav navbar-right">
                
                
                <li> <h3 class="tm">Welcome {location.state.name}, ID : {location.state.id}</h3></li>
                <li><a href="/login"><span class="glyphicon glyphicon-log-out"></span></a></li>
              </ul>
            </div>
          </div>
        </nav>
        <div class="sidenav">
        <div style={{ }}>
                    <TabList>
                    <Tab><a><b>Home</b></a></Tab>
                        <Tab><a><b>Subscribe</b></a></Tab>
                        <Tab><a><b>Publish</b></a></Tab>
                       
                    </TabList>
                </div>
            
            
          </div>
          
                
                        <div id="band" class="container clm" style={{  }}>
                        <br></br>
                        
                    <TabPanel>
                        <Home id={location.state.id} />
                    </TabPanel>

                    <TabPanel>
                    <Subscribe id={location.state.id} />
                    </TabPanel>

                    <TabPanel>
                        <Publish id={location.state.id} />
                        
                    </TabPanel>
                </div>
            </Tabs>
           
                
            
            
            
        


           



        </>
    );
}

export default MainPage;