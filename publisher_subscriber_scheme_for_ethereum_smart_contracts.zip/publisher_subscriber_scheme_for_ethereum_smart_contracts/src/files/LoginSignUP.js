import { useNavigate } from 'react-router-dom';
import "./login1.css"

function LoginSignUP() {

    // navigator to move around the page
    const navigate = useNavigate();

    // basic starting page...
    // nothing much to say here
    return (
        <>
             <br></br>
     <h2 class="log log1">Welcome to Publisher/Subscriber Project</h2><br></br>
            <div class="log2">
            <button class="login2" onClick={() => { navigate('/login') }}>Login</button><br></br>
            <button class="login2"onClick={() => { navigate('/signup') }}>SignUp</button>
            </div>

            

        </>
    );
}

export default LoginSignUP;