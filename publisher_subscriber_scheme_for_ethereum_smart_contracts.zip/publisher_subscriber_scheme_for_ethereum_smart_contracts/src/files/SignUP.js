import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import pubsub from '../contracts/pubsub';
import "./login1.css"

export default function SignUP() {

    // navigator to move around the pages
    const navigate = useNavigate();

    // user data state to handle submission
    const [userData, setUserData] = useState({
        name: "",
        email: "",
        password: "",
        addr: "",
    });

    // fn handle form fields
    const handleChangeOfFileds = (event) => {
        setUserData({ ...userData, [event.target.name]: event.target.value });
    }

    // register person in BC
    const regPubSol = async (_userid, _addr) => {
        await pubsub.methods.registerPerson(_userid).send({ from: _addr, gas: 1000000 });
    }

    // fn to handle submission process
    const handleSubmission = async (event) => {
        event.preventDefault();

        const res = await fetch("http://localhost:4000/signup", {
            method: "POST",
            body: JSON.stringify(userData),
            headers: {
                'Content-Type': 'application/json',
            },
        });

        const data = JSON.parse(await res.text());

        console.log(data.id);
        console.log(userData.addr);

        regPubSol(data.id, userData.addr);

        navigate('/login');

    }

    return (
        <>
        <br></br>
     <h2 class="log log5">SignUp Page</h2><br></br>
            <div class="log">
               
                <form onSubmit={handleSubmission}>
                <label for="fname">Enter name :</label><br></br>
                <input name="name" class="login"onChange={handleChangeOfFileds} type="text" value={userData.name}></input><br></br>
                <label for="fname">Enter email : </label><br></br>
                <input name="email" class="login"onChange={handleChangeOfFileds} type="text" value={userData.email}></input><br></br>
                
                <label for="fname">Enter password :  </label><br></br>
                <input name="password" class="login"onChange={handleChangeOfFileds} type="password" value={userData.password}></input><br></br>
                <label for="fname">Enter Acc Addr : </label><br></br>
                <input name="addr" class="login"onChange={handleChangeOfFileds} type="text" value={userData.addr}></input><br></br>
                <input class="sub"type="submit"></input>
                </form>
                <a href="/login">Login?</a>
            </div>
            
            
            
               
        </>
    );
}